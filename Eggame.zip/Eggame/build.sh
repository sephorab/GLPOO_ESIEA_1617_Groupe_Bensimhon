echo Build du TP Chien DAO
#mvn clean install eclipse:eclipse -Dmaven.test.skip
mvn clean install eclipse:eclipse