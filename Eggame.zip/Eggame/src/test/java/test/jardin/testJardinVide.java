package test.jardin;

import eggame.jardin.jardin;

public class testJardinVide {

	public static void main(String[] args) {
		jardin tabJardin = new jardin(4,4);
		tabJardin.afficherJardin();
	
	}

}
