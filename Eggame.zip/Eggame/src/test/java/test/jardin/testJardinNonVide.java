package test.jardin;

import eggame.jardin.jardin;

public class testJardinNonVide {

	public static void main(String[] args) {
		jardin tabJardin = new jardin(4,4);
		tabJardin.ajouterUnRocher(1, 1);
		tabJardin.ajouterUnEnfant(2,2);
		tabJardin.ajouterUnOeuf(3, 3);
		tabJardin.afficherJardin();

	}

}
