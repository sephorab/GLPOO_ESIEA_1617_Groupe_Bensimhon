package test.jardin;

import java.io.FileNotFoundException;

import eggame.jardin.jardin;

public class testJardinFichierTexte {

	public static void main(String[] args) throws FileNotFoundException {
		jardin tabJardin = new jardin(4,4);
		tabJardin.personnalisationJardin();
		tabJardin.afficherJardin();

	}

}
