package eggame.jardin;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class jardin{
	int tabJardin[][];
	int nbCols;
	int nbLigs;
	

public jardin (int nbCol, int nbLig){
	 tabJardin = new int[nbCol][nbLig];
	 nbCols = nbCol;
	 nbLigs = nbLig;
	 for(int i = 0; i < nbCol; i++){
		 for(int j = 0; j < nbLig; j++){
			 tabJardin[i][j] = 0;
		 }
	 }
}

public void personnalisationJardin() throws FileNotFoundException{
Scanner scanner = new Scanner(new File("src/main/resources/fichierJardin"));
char c ;
while (scanner.hasNext()){
c = scanner.next().charAt(0);

int coordonneeCol = scanner.nextInt();
int coordonneeLig = scanner.nextInt();

switch(c){
case 'O':
	ajouterUnOeuf(coordonneeCol, coordonneeLig);
	break;	

case 'E':
	ajouterUnEnfant(coordonneeCol, coordonneeLig);
	break;	

case 'R':
	ajouterUnRocher(coordonneeCol, coordonneeLig);
	break;		
}
}
scanner.close();
}

	
		

	
	public void ajouterUnRocher(int x, int y){
	tabJardin[x][y] = 1;
	}
	public void ajouterUnEnfant(int x, int y){
	tabJardin[x][y] = 11;
	}
	public void ajouterUnOeuf(int x, int y){
	tabJardin[x][y] = 21;
	}

	public void afficherJardin(){
		
		for(int j = 0; j < nbLigs; j++){
			 for(int i = 0; i < nbCols; i++){
				 System.out.print(tabJardin[i][j]+" ");
			 }
			 System.out.println();
		 }
		
	}

	
}
